import BasicStats 
import pandas as pd
import logging
import Binning
import LabelEncoding
import PearsonCorrelation
import Visualisation
import model

def main():

    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
    logger = logging.getLogger(__name__)
    # Load the dataset
    df = pd.read_csv("data/car_price_dataset.csv")
    logger.info("Dataset loaded successfully.")
    logger.info(f"DataFrame head:\n{df.head()}")

    df = BasicStats.process_data(df)
    
    logger.info("Dataset after BasicStat")

    df = Binning.binning(df)

    df = LabelEncoding.labelEncoding(df)

    df['Mileage'] = (df['Mileage'] - df['Mileage'].min()) / (df['Mileage'].max() - df['Mileage'].min())

    print(df)

    PearsonCorrelation.correlation(df)

    logger.info(f"\n{df.dtypes}")

    Visualisation.visualise(df)

    model.model(df)

if __name__ == '__main__':
    main()