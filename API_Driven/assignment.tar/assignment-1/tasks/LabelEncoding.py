import pandas as pd
import logging


def labelEncoding(df):
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
    logger = logging.getLogger(__name__)

    # Mapping for Fuel_type to numeric values
    fuel_mapping = {
        'Diesel': 1,
        'Petrol': 2,
        'Electric': 3,
        'Hybrid': 4
    }

    # Apply the mapping
    df['Fuel_Type'] = df['Fuel_Type'].map(fuel_mapping)

    transmission_mapping = {
        'Manual': 1,
        'Semi-Automatic': 2,
        'Automatic': 3
    }

    df['Transmission'] = df['Transmission'].map(transmission_mapping)


    brand_weights = {
    'Kia': 1,
    'Chevrolet': 2,
    'Mercedes': 5,
    'Audi': 4,
    'Volkswagen': 3,
    'Toyota': 3,
    'Honda': 2,
    'BMW': 5,
    'Hyundai': 2,
    'Ford': 2
    }

    df['Brand'] = df['Brand'].map(brand_weights)

    return df